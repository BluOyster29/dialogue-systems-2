## Lab 2: Call john

The folder contains code from the Call John assignment

### Output from terminal

(tdm) [gusroberth@GU.GU.SE@eduserv call_john_ddd_2019]$ tdm build
Building generated grammar for DDD 'call_john'.
[eng] Cleaning build directory 'build/eng'...Done.
Not using RASA NLU, will not clean RASA build directories.
[eng] Generating grammar.
[eng] Asserting that language grammar is lower case...Done.
[eng] Finished generating grammar.
[eng] Building generated grammar.
[eng] Finished building generated grammar.
[eng] Not using RASA NLU, will not generate and build RASA models.
[eng] Not using word list correction, will not generate word list.
[eng] No ASR specified, will not build language model.
Finished building generated grammar for DDD 'call_john'.
(tdm) [gusroberth@GU.GU.SE@eduserv call_john_ddd_2019]$ tdm test eng
Running interactiontests from call_john/test/interaction_tests_eng.txt
...........
----------------------------------------------------------------------
Ran 11 tests in 1.920s

### Difficulties faced

I found it slightly difficult navigating the tdm error outputs. I thought the lab was quiten nie 
